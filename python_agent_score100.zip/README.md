# 《Python 特務：滿分計畫》
### 國立臺灣大學「程式設計與網路資料搜集」(GenEdu5010) Exam 1 期中考專屬遊戲學習系統

---

## 🎮 遊戲簡介
本遊戲專為修習台大 **GenEdu5010 程式設計與網路資料搜集** 的同學設計，精準針對 **Week 1 至 Week 5** 範圍（I/O、字串、ASCII 編碼、串列記憶體機制、for/while 迴圈、函式預設參數與作用域、PEP 8 規範等）。

結合 **114-1 與 114-2 兩份考古題（共 128+ 題）** 的核心考點，所有題目均為**原創變形題**，杜絕死背答案，讓你在遊戲闖關與計時模考中徹底消化 Python 直譯器底層邏輯與高頻陷阱！

---

## 🚀 啟動與分享方式 (支援方案 A 與方案 C)

### 方案 C：單檔離線遊玩 / 壓縮包分享（最快、零門檻）
* **真・單一離線 HTML** (`python_agent_score100_standalone.html`)：
  * 已將題庫、合成音效、核心程式與 4 大機甲視覺圖以 Base64 完整打包。
  * **只需將該單一檔案傳給同學**，對方只要雙擊即可在任何電腦或手機瀏覽器離線遊玩，完全不需安裝 Python、不需要開伺服器，甚至不用解壓縮！
* **完整專案 ZIP 包** (`python_agent_score100.zip`)：
  * 適合直接丟到 Line / Discord / Google 雲端硬碟整包備份。
* **本機一鍵啟動**：
  * 執行 `python run_game.py`，會自動啟動本機伺服器並彈出遊戲視窗。

---

### 方案 A：GitHub Pages 雲端部署（公開網址、一鍵雲端同步）
* 專案內已準備好一鍵發布腳本 `deploy_to_github.py`。
* **操作流程（只需 1 分鐘）**：
  1. 在 [GitHub 建立新倉庫](https://github.com/new)（例如取名 `python-agent-score100`，設為 Public）。
  2. 複製該倉庫的網址（如 `https://github.com/你的帳號/python-agent-score100.git`）。
  3. 在本機執行：
     ```bash
     python deploy_to_github.py
     ```
     貼上你的倉庫網址，腳本會自動將專案推送到 main 分支。
  4. 至 GitHub 倉庫頁面 ➔【Settings】➔【Pages】➔ Build and deployment Source 選擇【Deploy from a branch】➔ 選擇【main】與【/ (root)】點擊【Save】。
  5. 約 1 分鐘後，即可獲得永久公開遊戲網址（例如：`https://你的帳號.github.io/python-agent-score100/`），分享給任何同學都能直接連線遊玩！

---

## 🌟 核心特色與功能模組

### 🗺️ 主軸一：主題式章節冒險（Story Campaign）
* **Chapter 1: 終端訊號基地**（print, sep/end 格式化, input, 型態轉換, PEP 8 風格）
* **Chapter 2: 字符密碼解析室**（字串切片 start:stop:step, 負索引, ord/chr ASCII 密碼位移）
* **Chapter 3: 資料矩陣防線**（串列參照別名 vs 淺拷貝, list.sort() vs sorted() 原地修改）
* **Chapter 4: 循環迴路之謎**（range 邊界, 雙層巢狀迴圈次數, break/continue, while-else）
* **Chapter 5: 核心指令與領域**（def, 預設引數, 可變預設參數 def f(x=[]) 陷阱, global 與 UnboundLocalError）
* **Chapter 6: 特務高階工具箱**（enumerate, zip 解包, 串列表達式 List Comprehension, 例外防禦）

> 💡 **每章均配備**：
> 1. **【觀念情報卡】**：考前 1 分鐘快速複習公式與規則。
> 2. **【基礎突擊戰】**：單一觀念確認，建立解題信心。
> 3. **【進階陷阱試煉】**：專攻歷屆最高失分點與代碼魔王題。

---

### ⚔️ 主軸二：刷題目與模擬考場（Exam Arena）
* **50 分鐘急速模考**：仿 114-1 Exam 1 規格（25 題跨章節隨機題，高壓計時）。
* **全真深度模擬考**：仿 114-2 規格（40 題大題量綜合試煉）。
* **10 題快速突擊 (Boss Rush)**：利用搭車、課間 5 分鐘隨時刷題練手感。
* **高頻陷阱突擊**：集中練習所有進階陷阱題。

---

### 🔍 亮點功能：Python Tutor 單步代碼追蹤解析
呼應 Week 2 投影片中的程式追蹤觀念（Tracing Code），每一題的解析均內建 **「單步代碼追蹤器」**：
* 點擊 **【上一步】/【下一步】**，動態觀察直譯器正在執行的行數。
* 即時顯示 **「變數記憶體快照 (Variables in Scope)」**，看清迴圈計數器、切片與指標位址的每一步變化！

---

### 📕 特務錯題情報庫（Mistake Vault）
* 歷次章節突擊或模考答錯的題目，系統自動納入錯題庫。
* 支援依章節篩選錯題。
* 點擊 **【重新挑戰】** 或 **【集中消滅所有錯題】**，單獨刷錯題，答對後即刻消滅，不再重複踩坑！

---

### 🔊 遊戲化回饋系統
* **特務軍階與升級**：從「見習探員」一路晉升至「系統總架構師」。
* **Combo 連擊獎勵**：連續答對激活動態音效與火焰計數。
* **純原生 Web Audio API**：內建合成音效（答對和弦、連擊升調、答錯沉音、升級號角），不依賴外部檔案，零延遲且免網路。
* **本地自動存檔**：進度與錯題本使用 `localStorage` 自動持久化保存。

---

## 🛠️ 技術規格
* 前端技術：HTML5、Tailwind CSS、Lucide Icons、Prism.js（代碼語法高亮）
* 音效架構：Web Audio API
* 題庫規模：75+ 道原創變形題，經 Python 3.12 直譯器驗證 100% 正確
* 跨平台相容：Windows / macOS / Linux / 行動裝置瀏覽器
